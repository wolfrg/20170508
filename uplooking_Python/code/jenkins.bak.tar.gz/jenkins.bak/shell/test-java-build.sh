#!/bin/bash
ssh 10.1.11.92 "sh /root/test-java.sh"
