#!/bin/bash
ls -al /root >/root/test.txt
