APP_CONFIG_FILE="/Users/bigv/yangdw/dev/training/python/project/ops/config/development.py"
export APP_CONFIG_FILE
python app.py
