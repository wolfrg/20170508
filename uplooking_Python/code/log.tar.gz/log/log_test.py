#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
LOG_FILE = "app.log"
logging.basicConfig(filename=LOG_FILE, level=logging.INFO)
# INFO:root:aaa
logging.info("这是测试log")
logging.error("error")
