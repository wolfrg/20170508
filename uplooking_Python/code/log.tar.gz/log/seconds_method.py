#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
import logging.config
from conf.config import config

logging.config.dictConfig(config)
logger = logging.getLogger('http')
logger.info("aaa")


