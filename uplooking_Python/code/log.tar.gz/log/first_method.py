#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging

LOG_FILE = "app.log"
#
## 创建logger
#logger = logging.getLogger('test')
## 设置默认级别
#logger.setLevel(logging.DEBUG)
#
## 创建Handler
#ch = logging.FileHandler(LOG_FILE)
#ch.setLevel(logging.INFO)
#
## 创建Formatter
#fmt = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
#formatter = logging.Formatter(fmt)
#
## 配置logger
## 为handler添加formatter
#ch.setFormatter(formatter)
#logger.addHandler(ch)
#
#logger.warn("aaaa.mess")
#logger.debug("info")

def get_formatter():
    fmt = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    formatter = logging.Formatter(fmt)
    return formatter

def get_logger(logger_name):
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    formatter = get_formatter()
    ch = logging.FileHandler(LOG_FILE)
    ch.setLevel(logging.INFO)
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    return logger

if __name__ == "__main__":
    db_logger = get_logger("db")
    http_logger = get_logger("http")
    http_logger.error("http error")
    db_logger.error("db error")

