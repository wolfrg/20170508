from db import MasterDB
db = MasterDB()