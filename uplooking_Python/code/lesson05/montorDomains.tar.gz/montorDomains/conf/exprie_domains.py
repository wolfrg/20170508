#!/usr/bin/env python
# -*- coding: utf-8 -*-
exprie_domains = [
        'bigvyy.cn',
        'bivyy.xyz',
        'mi-idc.commiui.com',
        'miliao.com',
        'tjqonline.cn',
        'xiaomi.tw',
        'hada.me',
        'wlimg.cn',
        'aleenote.com',
        'alinotes.cn',
        'x9m.cn',
        'midoujiang.com',
        'duokan.com',
        'mi-ae.cn',
        'mi-ae.net',
        'zhimi.com',
        'mizhuanqian.com',
        'miot-spec.org',
        'gancuidai.com',
        ]

