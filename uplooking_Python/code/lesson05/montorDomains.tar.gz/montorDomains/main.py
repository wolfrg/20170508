#!/usr/bin/env python
# -*- coding: utf-8 -*-
from core.monitor_domains import main

if __name__ == "__main__":
    main()
