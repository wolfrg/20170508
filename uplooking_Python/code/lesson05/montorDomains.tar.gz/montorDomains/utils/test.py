#!/usr/bin/env python
# -*- coding: utf-8 -*-

from utils.tools import sys_call

if __name__ == "__main__":
    cmd = "whois bivyy.cn"
    sys_call(cmd)


